# SIP-2018-starter
Starter code for the Girls Who Code 2018 Summer Immersion Program.
