# --- Define your functions below! ---


# --- Put your main program below! ---
def main():
  while True:
    answer = input("(What will you say?) ")
    print("That's cool!")


# DON'T TOUCH! Setup code that runs your main() function.
if __name__ == "__main__":
  main()