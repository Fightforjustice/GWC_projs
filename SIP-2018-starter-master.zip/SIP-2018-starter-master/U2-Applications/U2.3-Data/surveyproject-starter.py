
# Creates the dictionary to store responses.
answers = {}

'''
Below, write code that will pose the survey questions from the student prompt
to a user. Your program should save user input as a dictionary.
'''



# Print the context of the dictionary.
print(answers)
