# Twitter Data

This file contains sample Twitter data, to be used for the Twitter Code Along and Data Visualization Project.